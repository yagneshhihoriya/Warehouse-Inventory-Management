const express = require("express");
const path = require("path");
const fs = require("fs");
const bodyParser = require("body-parser");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

//static folder
app.use(express.static("static"));

//set view engine to ejs
app.set("view engine", "ejs");
app.set("views", __dirname + "/views");

let productsData = JSON.parse(
  fs.readFileSync(path.resolve(__dirname, "products.json"))
);

let inventoryData = JSON.parse(
  fs.readFileSync(path.resolve(__dirname, "inventory.json"))
).inventory;
console.log(inventoryData);

const productsArray = productsData.products;

app.get("/", (req, res) => {
  res.send("Home Page");
});

app.get("/products", (req, res) => {
  res.render("product.ejs", { products: productsData.products });
});

app.get("/products/:id", (req, res) => {
  const id = req.params.id;
  let data = productsArray.find((product) => product.pid == id);
  res.render("productArticles", { data: data, inventoryData: inventoryData });
});

app.get("/inventory", (req, res) => {
  res.render("inventory.ejs", { inventories: inventoryData });
});

app.get("/inventory/:id", (req, res) => {
  const id = req.params.id;
  let data = inventoryData.find((inventory) => inventory.art_id == id);
  console.log(data);
  res.render("inventoryArticle", { data: data });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log("Server started at port " + port);
  console.log("http://localhost:" + port);
});
